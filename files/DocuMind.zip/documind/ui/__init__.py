"""DocuMind user interface (Gradio)."""
